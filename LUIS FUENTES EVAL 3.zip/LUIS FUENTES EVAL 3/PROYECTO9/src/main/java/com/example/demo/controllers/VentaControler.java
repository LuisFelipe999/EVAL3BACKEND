package com.example.demo.controllers;



import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.example.demo.models.Producto;
import com.example.demo.models.Usuario;
import com.example.demo.models.Venta;
import com.example.demo.servicio.ProductoServicio;
import com.example.demo.servicio.UsuarioServicio;
import com.example.demo.servicio.VentaServicio;


@Controller
@RequestMapping("/venta")
public class VentaControler {

	//@Autowired
	//private Usuario usu;
	
	//@Autowired
	//private Producto  prod;
	@Autowired
	private UsuarioServicio gato;
	
	@Autowired
	private ProductoServicio perro;
	
			@Autowired
			//dependencia servicio
			private final VentaServicio gallina;
			
			public VentaControler(VentaServicio ventaServicio) {
				this.gallina = ventaServicio;
			}
			
		//@ModelAttribute("empleado") Empleado empleado, ejemplo pasar entidad a un jsp
			@RequestMapping("")
			public String index(@ModelAttribute("venta") Venta venta,Model model ) {
				//System.out.println("index");
				
				List<Venta> lista_ventas = gallina.findAll();
				model.addAttribute("lista_ventas", lista_ventas);
				model.addAttribute("lista_usuarios", gato.findAll());
				model.addAttribute("lista_productos", perro.findAll()); 
				
				return "venta.jsp";
			}
			
			@RequestMapping(value="/crear", method = RequestMethod.POST)
			public String crear(@Valid @ModelAttribute("venta") Venta venta) {
				System.out.println("crear "+ venta);
				//llamado a guardar la entidad
			
				
				
				//return "redirect:/usuario"; 
				 
				//Validación
				
				//En caso de un campo vacío
				//  if( producto.getApellido().isBlank() || producto.getNombre().isBlank() || producto.getRut().isBlank() || usuario.getEmail().isBlank()) {
					
				//	System.out.println("Error de tipo campo vacio");
					
				//	return "redirect:/usuario";
				// } 
				  
				
				//Verificar largo de apellido y nombre
				// if(usuario.getApellido().length() < 3 || usuario.getApellido().length() > 20 || usuario.getNombre().length() < 3 || usuario.getNombre().length() > 20) {
					
				//	System.out.println("Error El de longitud en el apellido/nombre");
				//	System.out.println("minimo de 3 carácteres y máximo de 20");
					
				//	return "redirect:/usuario";
				 // }
				
				//verificar si el email tiene una length correcta
			// 	if(usuario.getEmail().length() < 10){
					
				//	System.out.println("Error de longitud en el Email");
					
			//		return "redirect:/usuario";
			//	}
				
				
				//Verificar si el ruta tiene un largo correcto
			//	if(usuario.getRut().length() != 9) {
					
			//		System.out.println("Error rut incorrecto");
		//			return "redirect:/usuario";
		//		} 
			    Venta vent =  gallina.insertarVenta(venta);
				return "venta.jsp"; 
			}
			
			@RequestMapping(value="/actualizar/{id}", method = RequestMethod.GET)
			public String actualizar(@PathVariable("id") Long id, Model model) {
				System.out.println("actualizar id: "+ id); 
				
				Venta venta=gallina.buscarVenta(id); 
				model.addAttribute("venta", venta);
				//model.addAttribute("lista_usuarios",usuarioServicio.findAll())
				
				return "modificarventa.jsp";
			} 
			
			
			@RequestMapping(value="/modificar", method = RequestMethod.PUT)
			public String modificar(@Valid @ModelAttribute("venta") Venta venta) {
				System.out.println("modificar");
				gallina.modificarVenta(venta);
				
				  
				
			//	if(usuario.getApellido().isBlank() || usuario.getNombre().isBlank() || usuario.getRut().isBlank() || usuario.getEmail().isBlank()) {
					
				//	System.out.println("Error de tipo campo vacio");
					
			//		gato.modificarUsuario(usuario);
			//		return "redirect:/persona";
			//	}
				
				//Verificar largo de apellido y nombre
			//	if(usuario.getApellido().length() < 3 || usuario.getApellido().length() > 20 || usuario.getNombre().length() < 3 || usuario.getNombre().length() > 20) {
					
			//		System.out.println("Error El de longitud en el apellido/nombre");
			//		System.out.println("minimo de 3 carácteres y máximo de 20");
					
			//		return "redirect:/persona";
			//	}
				
				//verificar si el email tiene una length correcta
			//	if(usuario.getEmail().length() < 10){
					
			//		System.out.println("Error de longitud en el Email");
					
		//			return "redirect:/persona";
			//	}
				
				
				//Verificar si el ruta tiene un largo correcto
		//		if(usuario.getRut().length() != 9) {
					
		//			System.out.println("Modificacion de rut incorrecto");
		//			return "redirect:/persona";
		//		}
				return "redirect:/venta";
			}
			
			
			@RequestMapping(value="/eliminar", method = RequestMethod.POST)
			public String eliminar(@RequestParam("id") Long id) {
			System.out.println("Eliminar id: "+ id);
				gallina.eliminarVenta(id);
				return "redirect:/venta";
		}
			
			
			@RequestMapping(value="/eliminar2/{id}", method = RequestMethod.DELETE)
			public String eliminar2(@PathVariable("id") Long id) {
				System.out.println("Eliminar2 id: "+ id);
				gallina.eliminarVenta(id);
				return "redirect:/venta";
		}
			
			
			@RequestMapping("/buscar")
			public String buxcar() {
				return "redirect:/producto";
			}
		
		//@RequestMapping(value="/totalizar", method = RequestMethod.PUT)
		//	public String totalizar(@Valid @ModelAttribute("venta") Venta venta) {
					
		
			 
	//	}
				

	}


