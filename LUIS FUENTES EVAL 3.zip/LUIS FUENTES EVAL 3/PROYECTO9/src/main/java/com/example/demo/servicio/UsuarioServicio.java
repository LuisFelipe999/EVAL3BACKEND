package com.example.demo.servicio;

import javax.validation.Valid;
import java.util.Optional;

import org.springframework.stereotype.Service;
import java.util.List;

import com.example.demo.models.Usuario;
import com.example.demo.repositorios.UsuarioRepositorio;



@Service
public class UsuarioServicio {
	//logica de negocio o empresarial
		//dependencia repository
		private final UsuarioRepositorio eu;
		
		public UsuarioServicio(UsuarioRepositorio usuarioRepositorio) {
			this.eu = usuarioRepositorio;
		}

		public Usuario insertarUsuario(@Valid Usuario usuario) {
			// TODO Auto-generated method stub
			return eu.save(usuario);
		}

		public List<Usuario> findAll() {
			// retorna una lista de empleados
			return eu.findAll();
		}

		

		public void eliminarUsuario(Long id) {
			// TODO Auto-generated method stub
			eu.deleteById(id);
		}

		
		public void modificarUsuario(@Valid Usuario usuario) {
			// TODO Auto-generated method stub
			eu.save(usuario);
		
		

		
}

		public Usuario buscarUsuario(Long id) {
			// TODO Auto-generated method stub
			
			Optional<Usuario> oUsuario= eu.findById(id);
			
			if(oUsuario.isPresent()) {
				return oUsuario.get();
			}
			return null;
		} 
}