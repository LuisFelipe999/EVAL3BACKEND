package com.example.demo.controllers;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.models.Usuario;

import com.example.demo.servicio.UsuarioServicio;

@Controller
@RequestMapping("/usuario")
public class UsuarioControler {

		//	@Autowired
		//	private CategoriaServicio categoriaServicio;
			
			//dependencia servicio
			private final UsuarioServicio gato;
			
			public UsuarioControler(UsuarioServicio usuarioServicio) {
				this.gato = usuarioServicio;
			}
			
		//@ModelAttribute("empleado") Empleado empleado, ejemplo pasar entidad a un jsp
			@RequestMapping("")
			public String index(@ModelAttribute("usuario") Usuario usuario,Model model ) {
				//System.out.println("index");
				
				List<Usuario> lista_usuarios = gato.findAll();
				model.addAttribute("lista_usuarios", lista_usuarios);
			//	model.addAttribute("lista_categorias", categoriaServicio.findAll());
				return "usuario.jsp";
			}
			
			@RequestMapping(value="/crear", method = RequestMethod.POST)
			public String crear(@Valid @ModelAttribute("usuario") Usuario usuario) {
				System.out.println("crear "+ usuario);
				//llamado a guardar la entidad
			
				
				
				//return "redirect:/usuario"; 
				 
				//Validación
				
				//En caso de un campo vacío
		  	  	if( usuario.getApellido().isBlank() || usuario.getNombre().isBlank() || usuario.getRut().isBlank() || usuario.getEmail().isBlank()) {
					
		 			System.out.println("Error de tipo campo vacio");
					
		 			return "redirect:/usuario";
			 } 
				  
				
				//Verificar largo de apellido y nombre
				 if(usuario.getApellido().length() < 3 || usuario.getApellido().length() > 20 || usuario.getNombre().length() < 3 || usuario.getNombre().length() > 20) {
					
					System.out.println("Error El de longitud en el apellido/nombre");
					System.out.println("minimo de 3 carácteres y máximo de 20");
					
					return "redirect:/usuario";
				  }
				
				//verificar si el email tiene una length correcta
			 	if(usuario.getEmail().length() < 10){
					
					System.out.println("Error de longitud en el Email");
					
					return "redirect:/usuario";
				}
				
				
				//Verificar si el ruta tiene un largo correcto
			//	if(usuario.getRut().length() != 9) {
					
			//		System.out.println("Error rut incorrecto");
				//	return "redirect:/usuario";
		//	} 
			    Usuario usuar =  gato.insertarUsuario(usuario);
				return "usuario.jsp"; 
			}
			
			@RequestMapping(value="/actualizar/{id}", method = RequestMethod.GET)
			public String actualizar(@PathVariable("id") Long id, Model model) {
				System.out.println("actualizar id: "+ id); 
				
				Usuario usuario=gato.buscarUsuario(id); 
				model.addAttribute("usuario", usuario);
				//model.addAttribute("lista_usuarios",usuarioServicio.findAll())
				
				return "modicarUsuario.jsp";
			} 
			
			
			@RequestMapping(value="/modificar", method = RequestMethod.PUT)
			public String modificar(@Valid @ModelAttribute("usuario") Usuario usuario) {
				System.out.println("modificar");
				
				
				  
				
			//	if(usuario.getApellido().isBlank() || usuario.getNombre().isBlank() || usuario.getRut().isBlank() || usuario.getEmail().isBlank()) {
					
			//		System.out.println("Error de tipo campo vacio");
					
			//		gato.modificarUsuario(usuario);
			//		return "redirect:/usuario";
			//	}
				
				//Verificar largo de apellido y nombre
			//	if(usuario.getApellido().length() < 3 || usuario.getApellido().length() > 20 || usuario.getNombre().length() < 3 || usuario.getNombre().length() > 20) {
					
			//		System.out.println("Error El de longitud en el apellido/nombre");
			//		System.out.println("minimo de 3 carácteres y máximo de 20");
					
			//		return "redirect:/usuario";
			//	}
				
			//	//verificar si el email tiene una length correcta
			//	if(usuario.getEmail().length() < 10){
					
			//		System.out.println("Error de longitud en el Email");
					
				//    return "redirect:/usuario";
			//	}
				
		
				
				//Verificar si el ruta tiene un largo correcto
		//		if(usuario.getRut().length() != 9) {
					
		//		System.out.println("Modificacion de rut incorrecto");
		//			return "redirect:/usuario";
		//		}
				gato.modificarUsuario(usuario);
				return "redirect:/usuario";
			}
			
			
			@RequestMapping(value="/eliminar", method = RequestMethod.POST)
			public String eliminar(@RequestParam("id") Long id) {
			System.out.println("Eliminar id: "+ id);
				gato.eliminarUsuario(id);
				return "redirect:/usuario";
		}
			
			
			@RequestMapping(value="/eliminar2/{id}", method = RequestMethod.DELETE)
			public String eliminar2(@PathVariable("id") Long id) {
				System.out.println("Eliminar2 id: "+ id);
				gato.eliminarUsuario(id);
				return "redirect:/usuario";
		}
			
			
			@RequestMapping("/buscar")
			public String buxcar() {
				return "redirect:/usuario";
			}
		

	}

