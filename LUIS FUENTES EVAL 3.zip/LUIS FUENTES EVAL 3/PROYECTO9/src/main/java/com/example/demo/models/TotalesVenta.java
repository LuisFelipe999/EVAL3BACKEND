package com.example.demo.models;



public class TotalesVenta {

	private Venta cantidad;  
	private Venta precioProductoenCarro;
	
	
	
	public Venta getCantidad() {
		return cantidad;
	}
	public void setCantidad(Venta cantidad) {
		this.cantidad = cantidad;
	}
	public Venta getPrecioProductoenCarro() {
		return precioProductoenCarro;
	}
	public void setPrecioProductoenCarro(Venta precioProductoenCarro) {
		this.precioProductoenCarro = precioProductoenCarro;
	} 
	
	public int NumeroTotal() { 
		
		return cantidad.getCantidad()*precioProductoenCarro.getprecioProductoenCarro();
		
		
	}
	
	
	
	
}
