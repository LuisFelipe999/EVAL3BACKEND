package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.models.TotalesVenta;

@Controller
public class TotalesVentaControler {

	
	@GetMapping("/totalVenta")
	public String ViewForm(Model model)
	{
		model.addAttribute("TotalesVenta", new TotalesVenta());
		return "index";
	}
	
	@PostMapping("/NumeroTotal")
	public String addForm(@ModelAttribute TotalesVenta totalesVenta,BindingResult result,Model model)
	{
		model.addAttribute("totalesVenta",totalesVenta);
		return "calculate";
	}
}
	
	

