package com.example.demo.repositorios;


import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.models.Usuario;


@Repository
public interface UsuarioRepositorio extends CrudRepository<Usuario,Long> {

	
     List<Usuario> findAll();
	
	
}